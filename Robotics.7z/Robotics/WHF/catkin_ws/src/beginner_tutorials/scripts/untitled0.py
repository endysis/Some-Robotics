# -*- coding: utf-8 -*-
"""
Created on Thu Feb  2 16:21:51 2017

@author: computing
"""

import rospy
from std_msgs.msg import String 

print ("as")